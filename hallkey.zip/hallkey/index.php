<?php 
	require_once 'php/connect.php';
	
	$errors = array();
	
	if (isset($_POST['search'])) {
	$valueToSearch = $_POST['room_no'];
	$query = "SELECT t1.room_id, t1.room_no, t2.studid, t2.key_in_out FROM hall_rooms AS t1 JOIN hall_room_occupants AS t2 ON t1.room_id=t2.room_id WHERE t1.room_no='$valueToSearch' AND t1.hallid='SRC'";
	$search_result = $dbcon -> query($query);
	//echo $search_result;

		 if ($_POST['room_no'] == '') {
		 	$errors[] .= 'Empty room number';
		}
		 else if ($_POST['room_no'] == 0) {
		 	$errors[] .= 'Room number cannot be 0';
		 }

		 if (!empty($errors)) {
			echo display_errors($errors);
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Key Collection App</title>
	<meta charset="utf-8">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<h2 style="margin-top: 20px; background-color: #C3C3C3; padding-bottom: 10px;" class="text-center">Key Collection App</h2>
		<div style="margin-top: 50px;" class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6" style="background-color: #f8f8f8;">
				<div style="margin-top: 8px;" class="text-center">
					<form class="form" action="index.php" method="POST" id="form1">
						<div id="errors">
					
						</div>
						<label for="room_no" class="mb-2 mr-sm-3">Room Number*: </label>
						<input type="text" id="room_no" name="room_no" class="form-control mb-2 mr-sm-5" placeholder="Enter Key Number">
						<p id="available"></p>

						<input type="submit" id="search" name="search"  value="Search" class="btn btn-success">
					</form>
					<br>


					<form class="form" id="formview" method="POST">
					<div style="margin-top: 60px;">
						
						<table class="table table-bordered table-striped">
							<thead>
								<th>Recident</th>
								<th>Key</th>
								<!-- <th>Out</th> -->
							</thead>
							<tbody>
								<?php  ?>
								<tr class="bg-primary">
									<td>Recident Name</td>
									<td>Key In</td>
								</tr>
								

								<?php
								if (isset($_POST['search'])) { 
								while ($row = mysqli_fetch_assoc($search_result)): ?>
									<tr>
										<td> 
											<input type="hidden" name="room_no[]" value="<?php echo $row['room_id']; ?>">
											<input type="hidden" name="studid[]" id="stud" value="<?php echo $row['studid']; ?>">
											<?php echo $row['studid']; ?>
										</td>
										<?php 
											$sql = "SELECT * FROM hall_room_occupants WHERE key_in_out= 1";
											$results =$dbcon -> query($sql);
											if (isset($_GET['studid'])) {
												$id = $_GET['room_id'];
												$studid = $_GET['studid'];
												$activities2 = 'key in';
												$username = 'Porter';
												$sql1 = "UPDATE hall_room_occupants SET key_in_out = 0 WHERE studid = '$studid' AND room_id = '$id'";
												$dbcon -> query($sql1);
												header("Location: index.php");
										
											}

										 ?>
										<td> 
											<input type="radio" name="radiobtn[]" <?php echo ($row['key_in_out'] == 1) ? 'checked' : ''; ?> data-waschecked="<?php echo ($row['key_in_out'] == 1) ? 'true' : 'false'; ?>">  
										</td>
									</tr>
								<?php endwhile; 
							}?>
							</tbody>


						</table>
						<p><span id="stdname"></span></p>
						<input type="submit" id="submit" name="submit" value="Submit" class="btn btn-success"  />
					</div>
				</form>
					<div style="margin-bottom: 50px;"></div>
				</div>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
</body>

<script type="text/javascript">
	var formview = document.getElementById('formview');
	var radios = document.querySelectorAll("input[type='radio']");
	var student = document.querySelectorAll("input[type='hidden']");
	formview.onsubmit = function(evt){
		let data = new FormData(formview);
		data.delete('keys[]');

		for (var i = 0; i < radios.length; i++) {
			if (radios[i].checked) {
				data.append(`keys[]`, 1);
			}else{
				data.append(`keys[]`,0);
			}
		}
		fetch('http://localhost:8080/hallkey/submit.php', {
			method: 'POST',
			body: data
		}).then(res => res.json()).then(me => console.log(JSON.stringify(me)));

		return false;
	}


	$('input[name="radiobtn[]"]').click(function(){
		var $radio = $(this);

		if($radio.data('waschecked') == true){
			$radio.prop('checked', false);
			$radio.data('waschecked', false);
			//console.log('waschecked')
			// console.log($radio.data('waschecked') + "=>" + $radio);
		} else{
			$radio.data('waschecked', true);
			//console.log('checked')
			// console.log($radio.data('waschecked') + "=>" + $radio);
		}

		$radio.siblings('input[name="radiobtn[]"]').data('waschecked', false);
	});

</script>
</html>
