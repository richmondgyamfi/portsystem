<?php 
	require_once 'php/connect.php';

	$data = $_POST;
	$data = json_decode(json_encode($data), true);

	if (isset($data) && !empty($data)) {
		$lock_keys = $data['keys'];
		$rooms = $data['room_no'];
		$students = $data['studid'];
		$username = 'Porter';
		$activities2 = 'key not with student';
		$activities = 'key with student';

			foreach($students as $key => $value){
			$studentresult = "UPDATE hall_room_occupants SET key_in_out = '$lock_keys[$key]' WHERE studid = '$value' AND room_id = '$rooms[$key]'";
			echo $studentresult;

			$dbcon -> query($studentresult);

		if ($lock_keys[$key] == 1) {
				$sql2 = "INSERT INTO hall_key_logs(room_id, username, studid, activity,log_time) VALUES ('$rooms[$key]','$username', '$value', '$activities',CURRENT_TIMESTAMP)";
				echo $sql2;
				$dbcon -> query($sql2);
			}
			else{
				if ($lock_keys[$key] == 0) {
				$sql1 = "INSERT INTO hall_key_logs(room_id, username, studid, activity,log_time) VALUES ('$rooms[$key]','$username', '$value', '$activities2',CURRENT_TIMESTAMP)";
				echo $sql1;
				$dbcon -> query($sql1);
			}
		}	
			
	}	
	// if (isset($_POST['submit'])) {
	// 		# code...
	// 		$sql = "SELECT * FROM hall_room_occupants WHERE key_in_out= 1";
	// 		echo $sql;
	// 		$result = $dbcon -> query($sql);
	// 		$roomid = $_GET['room_id'];
	// 		$studid = $_GET['studid'];
	// 		$keylock = $_GET['key_in_out'];
	// 		$activities2 = 'key in';
	// 		$activities = 'key out';
	// 		$username = 'Porter';
	// 		if ($keylock == 1) {
	// 		$sql2 = "INSERT INTO hall_key_logs(room_id, username, studid, activity,log_time) VALUES ('$roomid','$username', '$studid', '$activities',CURRENT_TIMESTAMP)";
	// 		echo $sql2;
	// 		//$dbcon -> query($sql2);
	// 		}
	// 		else{
	// 			if ($keylock == 0) {
	// 			$sql1 = "INSERT INTO hall_key_logs(room_id, username, studid, activity,log_time) VALUES ('$roomid','$username', '$studid', '$activities2',CURRENT_TIMESTAMP)";
	// 			echo $sql1;
	// 			//$dbcon -> query($sql1);
	// 			}
	// 		}
	// 	}

	if (isset($_POST['room_no'])) {
			$room = $_POST['room_no'];
			$sql ="SELECT * FROM hall_room_occupants WHERE key_in_out = '$lock_keys[$key]' AND room_id = '$rooms[$key]'";


			$result = mysqli_query($dbcon, $sql);
			while ($row = mysqli_fetch_array($result)) {
				$data1 = $row["studid"];

		// 		if ($lock_keys[$key] == 1) {
		// 		$sql2 = "INSERT INTO hall_key_logs(room_id, username, studid, activity,log_time) VALUES ('$rooms[$key]','$username', '$data1', '$activities',CURRENT_TIMESTAMP)";
		// 		echo $sql2;
		// 		//$dbcon -> query($sql2);
		// 	}
		// 	else{
		// 		if ($lock_keys[$key] == 0) {
		// 		$sql1 = "INSERT INTO hall_key_logs(room_id, username, studid, activity,log_time) VALUES ('$rooms[$key]','$username', '$data1', '$activities2',CURRENT_TIMESTAMP)";
		// 		echo $sql1;
		// 		//$dbcon -> query($sql1);
		// 	}
		// }
			}
		}
		
			echo json_encode($data1);

		// if (isset($_POST['submit'])) {
		// 	$username = 'Charles';
		// 	$activities ='Key Out';
		// 	foreach($students as $key => $value){
		// 	$sql2 = 'INSERT INTO hall_key_logs(room_id, username, studid, activity,log_time) VALUES ("$rooms[$key]","$username","$values", "$activities","")';
		// 	$dbcon -> query($sql2);
		// }
		// }
		}

	 ?>